package us.shandian.giga.service;

public enum MissionState {
    None, Pending, PendingRunning, Finished
}
